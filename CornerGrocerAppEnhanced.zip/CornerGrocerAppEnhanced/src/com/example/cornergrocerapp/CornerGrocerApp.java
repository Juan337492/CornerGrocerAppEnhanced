package com.example.cornergrocerapp;

import java.util.*;
import java.io.*;

public class CornerGrocerApp {

    // Class to track grocery item frequencies
    public static class GroceryTracker {
        // Using a HashMap to store item frequencies
        private HashMap<String, Integer> itemFrequencies;

        // Constructor
        public GroceryTracker() {
            itemFrequencies = new HashMap<>();
        }

        /**
         * Reads items from a file and updates the frequency map.
         * Each token (separated by whitespace) is considered an item.
         *
         * @param filename The path to the input file.
         */
        public void loadDataFromFile(String filename) {
            try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // Use a Scanner to extract individual items from the line
                    Scanner lineScanner = new Scanner(line);
                    while (lineScanner.hasNext()) {
                        String item = lineScanner.next().trim();
                        if (!item.isEmpty()) {
                            // If the item already exists, increment its count; otherwise, add it with count 1
                            itemFrequencies.put(item, itemFrequencies.getOrDefault(item, 0) + 1);
                        }
                    }
                    lineScanner.close();
                }
            } catch (IOException e) {
                System.out.println("Error: Unable to load file " + filename);
            }
        }

        /**
         * Retrieves the frequency of a specific item.
         *
         * @param item The name of the item.
         * @return The frequency of the item or 0 if not found.
         */
        public int getItemFrequency(String item) {
            return itemFrequencies.getOrDefault(item, 0);
        }

        /**
         * Prints all items and their frequencies to the console.
         */
        public void printItemFrequencies() {
            for (Map.Entry<String, Integer> entry : itemFrequencies.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }

        /**
         * Prints a histogram where each item is followed by asterisks (*) equal to its frequency.
         */
        public void printItemHistogram() {
            for (Map.Entry<String, Integer> entry : itemFrequencies.entrySet()) {
                System.out.print(entry.getKey() + " ");
                int count = entry.getValue();
                for (int i = 0; i < count; i++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GroceryTracker tracker = new GroceryTracker();

        // Prompt the user for the file path
        System.out.print("Enter the file path: ");
        String filePath = scanner.nextLine();
        tracker.loadDataFromFile(filePath);

        int choice = 0;
        while (true) {
            // Display the menu options
            System.out.println("\nMenu:");
            System.out.println("1. Look up item frequency");
            System.out.println("2. Print item frequencies");
            System.out.println("3. Print item histogram");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            // Read and validate the user's menu choice
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            // Process the user's choice
            if (choice == 1) {
                System.out.print("Enter the item: ");
                String item = scanner.nextLine();
                System.out.println("Frequency: " + tracker.getItemFrequency(item));
            } else if (choice == 2) {
                tracker.printItemFrequencies();
            } else if (choice == 3) {
                tracker.printItemHistogram();
            } else if (choice == 4) {
                System.out.println("Exiting program.");
                break;
            } else {
                System.out.println("Invalid choice. Please select again.");
            }
        }

        scanner.close();
    }
}
